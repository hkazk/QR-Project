document.querySelectorAll('.categories-button').forEach(button => {
    button.addEventListener('click', () => {
        const category = button.dataset.category;
        const filteredProducts = products.filter(product => product.category === category);
        listProductHTML.innerHTML = '';
        filteredProducts.forEach(product => {
            let newProduct = document.createElement('div');
            newProduct.dataset.id = product.id;
            newProduct.classList.add('item');
            newProduct.innerHTML = `
                <img src="${product.image}" alt="">
                <h2>${product.name}</h2>
                <div class="price">$${product.price}</div>
                <button class="addCart">Add To Cart</button>
                <button class="showDetails">Show Details</button>`;
            listProductHTML.appendChild(newProduct);
        });
    });
});
