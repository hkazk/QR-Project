document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("headToMenu").addEventListener("click", function(event){
        event.preventDefault();
        window.location.href = "html/view1.html";
    });
});