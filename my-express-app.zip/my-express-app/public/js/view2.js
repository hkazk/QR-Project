function formatText(command) {
    document.execCommand(command, false, null);
}

function changeTextColor() {
    let color = prompt("Enter a color (name or hex):", "black");
    document.execCommand('foreColor', false, color);
}
