document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id');

    fetch('products.json')
    .then(response => response.json())
    .then(data => {
        const product = data.find(product => product.id === parseInt(productId));

        if (product) {
            const productInfo = document.querySelector('.product-info');
            productInfo.innerHTML = `
                <h2>${product.name}</h2>
                <img src="${product.image}" alt="${product.name}">
                <p>Price: $${product.price}</p>
                <p>Description: ${product.description}</p>
                <!-- Add any other product details you want to display -->
            `;
        } else {
            console.error('Product not found');
        }
    })
    .catch(error => {
        console.error('Error fetching product details:', error);
    });
});

document.querySelector('.menu-button').addEventListener('click', () => {
    window.location.href = '/index.html';
});

document.querySelector('.categories-button').addEventListener('click', () => {
    window.location.href = '/html/view1.1.html';
});
